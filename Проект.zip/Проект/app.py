from flask import Flask 
from flask import render_template
from flask import request
from flask import redirect
import sqlite3

app = Flask(__name__)

connection = sqlite3.connect('my_database.db' , check_same_thread=False)
cursor = connection.cursor() 

def productDB(): 
    listDB = cursor.execute('SELECT * FROM product')
    return listDB.fetchall()

def one_productDB(id): 
    listDB = cursor.execute('SELECT * FROM product WHERE id='+id)
    return listDB.fetchall()


@app.route('/') #главная страница
def index ():
    shop= productDB()
    return render_template("index.html", shop = shop)

@app.route('/about') #о нас
def about():
    return render_template("about.html")


@app.route('/search')
def search():
    query = request.args.get('q', '')
    
    # Полный список товаров с изображениями
    all_products = [
        {
            "name": "Balenciaga 3b", 
            "price": "7999.0",
            "image": "https://tse4.mm.bing.net/th/id/OIP.duE6t9fK0udSzsTbqtp46gHaJI?rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        {
            "name": "Balenciaga 3xl extreme", 
            "price": "6999.0",
            "image": "https://tse2.mm.bing.net/th/id/OIP.SScBJrP4uW6QAk0d5bxtygHaHa?rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        {
            "name": "Balenciaga Cargo", 
            "price": "7999.0",
            "image": "https://tse3.mm.bing.net/th/id/OIP.9CIZbhA1XDFo-S_pbcycDgHaE7?rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        {
            "name": "Balenciaga 10xl", 
            "price": "7999.0",
            "image": "https://tse4.mm.bing.net/th/id/OIP.-De7Tx0Lt1yBpOpBNymldgHaJQ?rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        
        {
            "name": "Tripp NYC", 
            "price": "8999.0",
            "image": "https://tse1.mm.bing.net/th/id/OIP.fVV_nSYE9I7PXJaiGLsJjgHaLG?rs=1&pid=ImgDetMain&o=7&rm=3"
        },
        {
            "name": "Футболка conjunctiva", 
            "price": "8888.0",
            "image": "https://60.img.avito.st/image/1/1.h36hqba4K5eXAOmSo9fKYpoIKZEfCKmf1w0plREAI50X.KbQqCwbaiP6pFn7cNzleDqmglcHxZCbARSLxYa91UGM"
        },
        {
            "name": "Тишка hikikomori kai", 
            "price": "7777.0",
            "image": "https://10.img.avito.st/image/1/1.qRGeY7a4BfjY0NP2wHHsKoTCB_4gwvfq_MwH-i7KDfIo.5OhcwJNw_JARyQDp9NiDpIdyRXQiKG6S-DahuBfoMFg"
        },
        {
            "name": "Футболка cruelty", 
            "price": "9999.0",
            "image": "https://sun9-77.userapi.com/s/v1/ig2/qwOEmRowVhlMZ_d2DbQTO0NztDObyzWbw5QB3J7z8nCbT27D1PV9sRi5dSwoSSWpN3MghaKaqXj7WLE2YV69eilA.jpg?quality=95&as=32x32,48x48,72x72,108x108,160x160,240x240,360x360,480x480,540x540,640x640,720x720,1080x1080,1280x1280,1440x1440,2000x2000&from=bu&u=9glCOCChOzzAjJM_4DVn8qAJdsLHaMsQG90sG-Pyazw&cs=540x0"
        }
    ]
    
    # Фильтрация товаров по запросу
    if query:
        filtered_products = [product for product in all_products 
                           if query.lower() in product['name'].lower()]
    else:
        filtered_products = []
    
    return render_template('search.html', 
                         query=query, 
                         products=filtered_products)


@app.route('/contact') #контакты 
def contact():
    return render_template("contact.html")

@app.route('/order/<id>')  
def order_page(id):
    tovar = one_productDB(id)
    if tovar:
        product = tovar[0]  # Берем первый товар из результата
        return render_template("order.html", tovar=product)
    else:
        return "Товар не найден"

@app.route('/user/<username>')
def user_profile(username):
    return render_template("index.html", name = username)

# Логин
@app.route("/login")
def login():
    return render_template("login.html", title="Вход и регистрация")


if __name__ == '__main__':  #точка входа нашей программы
    print("сервер запущен") #для проверки
    app.run (debug=True)
 